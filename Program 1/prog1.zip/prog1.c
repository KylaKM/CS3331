/* ----------------------------------------------------------- */
/* NAME : Kyla Kane-Maystead                 User ID: kakanema */
/* DUE DATE : 02/12/2020                                       */
/* PROGRAM ASSIGNMENT #1                                       */
/* FILE NAME : prog1.c (your unix file name)                   */
/* PROGRAM PURPOSE :                                           */
/*    A warm-up program to practice using system calls fork(), */
/*     wait(), and exit().				       */
/* ----------------------------------------------------------- */
#include <stdio.h>
#include <stdlib.h>
#include <sys/wait.h>
#include <unistd.h>
#include <string.h>
#include <math.h>
#include <time.h>

long fibonacci(int n);
float buffon(long r);
void integration(long s);
void bernoulli(unsigned long m);

int main(int argc, char** argv) {
	
	if(argc < 5) {
		write(2, "Not enough arguments\n", 21);
		return 1;
	}
	if(argc > 5) {                                                                        
		write(2, "Too many arguments\n", 19);
                return 1;
        }
	
	/*cast arguments*/
	unsigned long m = strtoul(argv[1], NULL, 0);
	int n = atoi(argv[2]);
	long r = atol(argv[3]);
	long s = atol(argv[4]);

	printf("Main Process Started\n");
	
	int i, wpid, pid;
	int status = 0;
	for(i = 0; i < 4; i++) {
		if((pid = fork()) != 0) { /*If parent process print child process info*/
			if(i == 0) { /*First Process*/
				printf("Fibonacci Number %d\n", n);							}
			else if(i == 1) { /*Second Process*/
				printf("Buffon's Needle Iterations = %ld\n", r); 					}
			else if(i == 2) { /*Third Process*/
				printf("Integration Iterations     = %ld\n", s);
			}
			else { /*Fourth Process*/
				printf("Approx. e Iterations       = %lu\n", m);
			}
		}
		else if(pid < 0) {
			printf("Error in fork\n");
			return 1;
		}
		else { /*Child Processes*/
			if(i == 0) {  /*First Child Process for fib method*/
				printf("Fibonacci Process Created\n");
				printf("      Fibonacci Process Started\n");                  
				printf("      Input Number %d\n", n);
				long fib = fibonacci(n);
				printf("      Fibonacci Number f(%d) is %ld\n", n, fib);
				printf("      Fibonacci Process Exits\n");
			}
			else if(i == 1) {  /*Second Child Process for buffon method*/
				printf("Buffon's Needle Process Created\n");
				printf("         Buffon's Needle Process Started\n");
				printf("         Input Number %ld\n", r);
				float buf = buffon(r);
				printf("         Estimated Probability is %.5f\n", buf);
        			printf("         Buffon's Needle Process Exits\n");
			} 
			else if(i == 2) {  /*Third Child Process for sin integration method*/
				printf("Integration Process Created\n");	
				printf("            Integration Process Started\n");
				printf("            Input Number %ld\n", s);
				integration(s);
				printf("            Integration Process Exits\n");
			}
			else {  /*Fourth Child Process for e approximation method*/
				printf("Approximation of e Process Created\n");
				printf("   Approximation of e Process Started\n");
				printf("   Maximum of the Exponent %lu\n", m);
				bernoulli(m);	
			}
			exit(0);  /*exit child processes so that they don't continue in loop*/
		}
	}
	printf("Main Process Waits\n");
	
	int j;
	for(j = 0; j < 4; j++) {
		wait(&status); /*wait for all children to exit*/
	}

	printf("Main Process Exits\n");
}


/* ----------------------------------------------------------- */
/* FUNCTION  Fibonacci Number: (fibonacci)                     */
/* 	 calculate the nth fibonacci number with recursion     */
/* PARAMETER USAGE :                                           */
/*	n -> number of fibonacci number to calculate           */
/* FUNCTION CALLED :                                           */
/*    	fibonacci()                                            */
/* ----------------------------------------------------------- */
long fibonacci(int n) {
	if(n == 0) {
		return 0;
	}
	else if(n == 1) {
		return 1;
	}
	else {
		return (fibonacci(n - 1) + fibonacci(n - 2));
	}
}

/* ----------------------------------------------------------- */
/* FUNCTION  Buffon's Needle: (buffon)                         */
/*     simulates throwing a needle r times 		       */
/*	and estimates probability			       */
/* PARAMETER USAGE :                                           */
/*    r -> number of times needed to simulate needle throwing  */
/* FUNCTION CALLED :                                           */
/*    N/a 					               */
/* ----------------------------------------------------------- */
float buffon(long r) {
	int i;
	long count = 0;
	float pi = acos(-1.0) * 2;
	srand(time(0));
	for(i = 0; i < r; i++) {  /*iterate r times*/
		
		/*generate random numbers in ranges [0, 1) and [0, 2pi)*/
		float d = ((float)rand()/(float)(RAND_MAX));
		float a = ((float)rand()/(float)(RAND_MAX)) * pi;
		
		float tot = sin(a) + d;
		if(tot < 0 || tot > 1) {  /*monitor when needle crosses dividing line*/
			count+=1;		
		}
	}
	float prob = (((double)count)/r); /*calculate probability*/
	return prob;	
}

/* ----------------------------------------------------------- */
/* FUNCTION  sin(x) integration: (integration)                 */
/*       computes integration of sin(x) between 0 and pi       */
/* PARAMETER USAGE :                                           */
/*      s -> number of times to iterate                        */         
/* FUNCTION CALLED :                                           */
/*      N/a                                                    */
/* ----------------------------------------------------------- */
void integration(long s) {
	float pi = acos(-1.0);
	srand(time(0));
	long t = 0;
	int i;
	for(i = 0; i < s; i++) {  /*iterate s times*/
		
		/*generate random numbers in ranges [0, 1) and [0, pi)*/
		float a = ((float)rand()/(float)(RAND_MAX)) * pi;
		float b = ((float)rand()/(float)(RAND_MAX));
		
                if(b <= sin(a)) {  /*monitor if point is in the area*/
			t+=1;
		}
	}
	
	printf("            Total Hit %d\n", t);
	
	float area = (t/(double)s) * pi; /*calculate area*/
	
	printf("            Estimated Area is %f\n", area);
}

/* ----------------------------------------------------------- */
/* FUNCTION  Bernolli's estimate of constant e : (bernoulli)   */
/*     the purpose of this function                            */
/* PARAMETER USAGE :                                           */
/*    m -> maximum exponent to be used                         */
/* FUNCTION CALLED :                                           */
/*    N/a					               */
/* ----------------------------------------------------------- */
void bernoulli(unsigned long m) {
	unsigned long i = 1;
	double res = 0.0;
	double diff = 0.0;
	while(i <= m) {  /*continue if i is less than or equal to max (m)*/
		
		/*calculate estimate of e*/
		double express = (1.0 + (1.0 / i));
		res = pow(express, i);
		
		/*calculate absolute value difference between*/
		/*estimate and exact*/
		if(res > exp(1.0)) {
			diff = res - exp(1.0);
		}
		else {
			diff = exp(1.0) - res;
		}
		
		printf("%18lu    %.15f    %.15f\n", i, res, diff);
		
		if(i < 10) { /*for printing i = 1,...,10*/
			i++;
		}
		else if(i == 10) { /*once i = 10 is done printing switch to 16*/
			i = 16;
		}
		else {  /*double i every iteration*/
			i = i*2;
		}				
	}
}
